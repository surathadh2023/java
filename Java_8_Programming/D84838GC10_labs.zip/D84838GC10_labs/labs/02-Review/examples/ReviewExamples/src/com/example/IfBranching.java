/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

public class IfBranching {

    public static void main(String args[]) {
        int x = 30;

        if (x < 20) {
            System.out.print("This is if statement\n");
        } else {
            System.out.print("This is else statement\n");
        }
    }
}
