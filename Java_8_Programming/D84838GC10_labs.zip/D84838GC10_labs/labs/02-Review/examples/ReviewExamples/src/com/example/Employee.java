/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

public class Employee {

    public int empId;
    public String name;
    public String ssn;
    public double salary;

    public Employee() {
    }

    public int getEmpId() {
        return empId;
    }
}
