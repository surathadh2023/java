package com.example;

public class Simple{

    public static void main(String args[]){
        
    }
}
