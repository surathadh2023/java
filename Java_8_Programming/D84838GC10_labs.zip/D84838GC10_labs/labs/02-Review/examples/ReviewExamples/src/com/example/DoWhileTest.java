
package com.example;

public class DoWhileTest {

    public static void main(String args[]) {

        int x = 30;

        do {
            System.out.print("value of x : " + x);
            x++;
            System.out.print("\n");
        } while (x < 20);
    }
}
