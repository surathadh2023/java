/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

/**
 *
 * @author anshenoy
 */
public class Ifelseif1 {

    public static void main(String args[]) {
        int studentGrade = 75;

        if (studentGrade >= 90) {
            System.out.println("A");
        } else if (studentGrade >= 80) {
            System.out.println("B");
        } else if (studentGrade >= 70) {
            System.out.println("C");
        } else if (studentGrade >= 60) {
            System.out.println("D");
        } else {
            System.out.println("F");
        }

    }
}
