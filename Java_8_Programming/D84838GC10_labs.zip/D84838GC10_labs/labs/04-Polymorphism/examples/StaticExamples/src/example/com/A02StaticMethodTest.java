package example.com;

public class A02StaticMethodTest {
  public static void main(String[] args) {
    StaticHelper.printMessage("hello");
  }
}
