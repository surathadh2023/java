package test;

public class Foo3 {
    private int result = 20;
    protected int getResult() {
        return this.result;
    }
}